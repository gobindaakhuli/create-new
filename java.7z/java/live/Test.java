package live;

import music.Playable;
import music.string.Veena;
import music.wind.Saxophone;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Saxophone s=new Saxophone();
		  s.play();
		  Veena v=new Veena();
		     v.play();
		     Playable p=s;
		     p.play();
		     Playable p2=v;
		     p2.play();
	}

}
