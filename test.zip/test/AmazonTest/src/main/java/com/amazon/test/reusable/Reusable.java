package com.amazon.test.reusable;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class Reusable {
	public static Properties OR_AT_HOME_PAGE;
	public static Properties OR_AT_LOGIN_PAGE;
	public static Properties OR_AT_PLPPDP_PAGE;
	public static Properties OR_AT_FULLCART_PAGE;
	public static final String FILE_PATH=".\\src\\main\\resources\\Property.properties";
	public static Properties p = new Properties();
	public static void initProperties() throws IOException {
		loadPropertyFile();
		System.out.println("************** Property file load successfully **************");
	}
	
	/***
	 * Load all property file to make available all xpath on execution time
	 * @throws IOException 
	 */
	public static void loadPropertyFile() throws IOException {
		FileInputStream propertyInputFile = null;
		propertyInputFile = new FileInputStream(System.getProperty("user.dir") + "//src//main//resources//ATHomePage.properties");
		OR_AT_HOME_PAGE = new Properties();
		OR_AT_HOME_PAGE.load(propertyInputFile);
		
		propertyInputFile = new FileInputStream(System.getProperty("user.dir") + "//src//main//resources//ATLoginPage.properties");
		OR_AT_LOGIN_PAGE = new Properties();
		OR_AT_LOGIN_PAGE.load(propertyInputFile);
		
		propertyInputFile = new FileInputStream(System.getProperty("user.dir") + "//src//main//resources//ATPlpPdpPage.properties");
		OR_AT_PLPPDP_PAGE = new Properties();
		OR_AT_PLPPDP_PAGE.load(propertyInputFile);
		
		propertyInputFile = new FileInputStream(System.getProperty("user.dir") + "//src//main//resources//ATFullCartPage.properties");
		OR_AT_FULLCART_PAGE = new Properties();
		OR_AT_FULLCART_PAGE.load(propertyInputFile);
	}
}
